# CRANKWARE — PATCH CIRÚRGICO DE COMPATIBILIDADE

**Base:** CRANKWARE-ROT.zip fornecido pelo utilizador em 2026-11-02.
**Âmbito:** APENAS compilaçao e compatibilidade de toolchain.

## Alterações (exatamente 2 ficheiros)

1. `CRANKWARE-ROT/BUILD_CRANKWARE_INSTALLER_WINDOWS.ps1`
   - `[switch]$Clang = $true`: seleciona ClangCL por defeito.
   - Elimina a escolha acidental do MSVC incompatível com os vetores GNU e assembly inline do Harmor / Ogun / FruityShapers, sem modificar o DSP.

2. `CRANKWARE-ROT/CMakeLists.txt`
   - Biblioteca Vorbis: quando o front-end do compilador é MSVC/clang-cl, usa `/FI` em vez de `-include`.
   - Com GNU Clang/GCC mantém `-include` e `-w`.
   - Evita que `clang-cl` ignore a flag do header de prefixo, que pode levar a erros de compilação/ligação.

**Nenhuma outra linha de código ou asset foi alterada.**
Não foram renomeados sintetizadores, marcas, ficheiros, funções ou estruturas de dados.

## Aplicar sem perder nada

1. Guarda uma cópia de segurança da tua pasta `CRANKWARE-ROT`.
2. Extrai este PATCH para a PASTA QUE CONTÉM `CRANKWARE-ROT` (não para dentro dela), aceitando substituir 2 ficheiros.
3. Não apagues o projeto original nem os seus ficheiros.
4. Inicia `CRANKWARE-ROT/COMPILAR_E_CRIAR_INSTALADOR.bat`. O PowerShell usa agora ClangCL por defeito.

Requisitos: Windows x64, VS 2022 com ClangCL (toolset), CMake, Git; NSIS para o instalador.

## Cópia completa limpa

A outra opção, `CRANKWARE_COMPATIBILIDADE_FONTE_LIMPA.zip`, é uma cópia extraída
**do ZIP original recebido**, alterando exatamente os mesmos dois ficheiros.
Foram excluídas SOMENTE as pastas de build geradas `build-crankware-*`, porque
contêm caches, objetos e caminhos dependentes do PC; não são código-fonte.
Os restantes 1784 ficheiros são byte a byte iguais aos originais.

## Evidências de validação

- `cmake` + Clang 17 (Linux), `LYNX_BUILD_APP=OFF`: CONFIGURAÇÃO OK.
- Bibliotecas Vorbis e WavPack compiladas com Clang 17 (Linux): OK.
- Biblioteca `lynx_core` completa compilada com Clang 17 (Linux): OK, 1 aviso não fatal em `VfxScript.cpp` (enum `program` não tratado).
- Trecho real de sintaxe GNU dos tipos HarmorV4/V2 e assembly de Ogun testado com `clang-cl` 17: OK.
- Compilação completa da interface JUCE no Windows: NÃO EXECUTADA.
- Execução da DAW no Windows e instalador final: NÃO VERIFICADOS.

Esta alteração corrige o erro de SELEÇÃO do compilador e o flag Vorbis no ClangCL;
não é uma garantia de que todo o projeto Windows esteja livre de outros erros.
