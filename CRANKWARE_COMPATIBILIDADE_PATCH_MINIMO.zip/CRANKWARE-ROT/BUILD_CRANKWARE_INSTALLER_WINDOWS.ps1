# CRANKWARE // ROT  - compile native Windows DAW & produce signed-format *unsigned* NSIS installer.
# Run on Windows 10/11 x64: powershell -NoProfile -ExecutionPolicy Bypass -File .\BUILD_CRANKWARE_INSTALLER_WINDOWS.ps1
# The executable remains LYNX.exe to preserve source integration, but is displayed as CRANKWARE.
param(
    [switch]$Clang = $true,
    [ValidateRange(1, 128)][int]$Parallel = 4
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Set-Location -LiteralPath $PSScriptRoot

function Say([string]$message) { Write-Host "[CRANKWARE] $message" -ForegroundColor Green }
function Fail([string]$message) { throw "[CRANKWARE] $message" }
function NeedTool([string]$command, [string]$wingetId) {
    $tool = Get-Command $command -ErrorAction SilentlyContinue
    if ($tool) { return }
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Fail "Falta $command. Instala $wingetId e volta a correr o script."
    }
    Say "A instalar $command ($wingetId), caso ainda nao exista..."
    & winget install --id $wingetId --exact --accept-package-agreements --accept-source-agreements --silent
    if ($LASTEXITCODE -ne 0) { Fail "Nao foi possivel instalar $command automaticamente." }
    $env:PATH = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User') + ';' + $env:PATH
    if (-not (Get-Command $command -ErrorAction SilentlyContinue)) { Fail "Instalacao de $command concluida, mas nao apareceu no PATH. Abre um PowerShell novo e volta a correr." }
}

function FindVS {
    $v = @("${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe", "${env:ProgramFiles}\Microsoft Visual Studio\Installer\vswhere.exe")
    foreach ($p in $v) {
        if (Test-Path -LiteralPath $p) {
            $vs = & $p -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationVersion
            if ($LASTEXITCODE -eq 0 -and $vs) { return $vs.Trim() }
        }
    }
    return $null
}

function FindNSIS {
    $c = Get-Command makensis -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    foreach ($p in @("${env:ProgramFiles(x86)}\NSIS\makensis.exe", "${env:ProgramFiles}\NSIS\makensis.exe", "$env:LOCALAPPDATA\Programs\NSIS\makensis.exe")) {
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

Say 'Verificar compilador e ferramentas...'
NeedTool 'git' 'Git.Git'
NeedTool 'cmake' 'Kitware.CMake'
$vs = FindVS
if (-not $vs) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { Fail 'Falta Visual Studio 2022 Build Tools com C++. Instala Desktop development with C++.' }
    Say 'Instalar Visual Studio 2022 Build Tools com MSVC x64 e Windows SDK (pode pedir elevacao)...'
    & winget install -e --id Microsoft.VisualStudio.2022.BuildTools --accept-package-agreements --accept-source-agreements --override '--passive --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended'
    if ($LASTEXITCODE -ne 0) { Fail 'Visual Studio Build Tools nao instalado. Instala manualmente Desktop development with C++.' }
    $vs = FindVS
    if (-not $vs) { Fail 'Nao foi detetado MSVC apos instalacao. Reinicia o PowerShell e volta a correr.' }
}
$major = [int]($vs.Split('.')[0])
$generator = switch ($major) {
    17 { 'Visual Studio 17 2022' }
    18 { 'Visual Studio 18 2026' }
    default { Fail "Versao Visual Studio nao suportada: $vs. Requer 2022 ou 2026." }
}

$nsis = FindNSIS
if (-not $nsis) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { Fail 'Falta NSIS 3. Instala-o antes de compilar o instalador.' }
    Say 'Instalar NSIS 3...'
    & winget install -e --id NSIS.NSIS --accept-package-agreements --accept-source-agreements --silent
    if ($LASTEXITCODE -ne 0) { Fail 'Nao foi possivel instalar NSIS. Instala NSIS 3 manualmente.' }
    $nsis = FindNSIS
    if (-not $nsis) { Fail 'NSIS nao encontrado apos a instalacao. Reinicia PowerShell e volta a correr.' }
}

$buildName = if ($Clang) { 'build-crankware-clang' } else { 'build-crankware-windows' }
$build = Join-Path $PSScriptRoot $buildName
$dist = Join-Path $PSScriptRoot 'dist'
$stage = Join-Path $dist 'stage'
New-Item -ItemType Directory -Path $dist -Force | Out-Null
Say 'Configurar CMake; a primeira vez precisa de Internet para JUCE 8.0.4...'
$configureArgs = @('-S', $PSScriptRoot, '-B', $build, '-G', $generator, '-A', 'x64', '-DLYNX_BUILD_APP=ON', '-DLYNX_PATCH_JUCE=ON')
if ($Clang) {
    $configureArgs += @('-T', 'ClangCL')
    $juceSource = Join-Path $PSScriptRoot 'build-crankware-windows\_deps\juce-src'
    if (Test-Path -LiteralPath (Join-Path $juceSource 'CMakeLists.txt')) {
        $configureArgs += "-DFETCHCONTENT_SOURCE_DIR_JUCE=$juceSource"
    }
}
Say ('cmake ' + (($configureArgs | ForEach-Object { '"' + $_ + '"' }) -join ' '))
& cmake @configureArgs
if ($LASTEXITCODE -ne 0) { Fail 'Configuracao CMake falhou. Verifica acesso ao GitHub, JUCE e dependencias.' }
Say 'Compilar DAW CRANKWARE (Release x64)...'
$buildArgs = @('--build', $build, '--config', 'Release', '--target', 'LYNX', '--parallel', $Parallel)
if ($Clang) {
    # ClangCL's MSBuild integration otherwise compiles each project's sources serially.
    $buildArgs += @('--', '/p:MultiProcCL=true', "/p:MultiProcMaxCount=$Parallel")
}
& cmake @buildArgs
if ($LASTEXITCODE -ne 0) { Fail 'Compilacao falhou: consultar as mensagens CMake/MSVC acima.' }
$exe = Get-ChildItem -LiteralPath $build -File -Filter 'LYNX.exe' -Recurse | Where-Object { $_.FullName -match '[\\/]Release[\\/]' } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $exe) { Fail 'Nao foi produzido LYNX.exe; instalador NAO sera criado.' }
if ((Get-Item -LiteralPath $exe.FullName).Length -lt 1024 * 1024) { Fail 'Executavel demasiado pequeno. Abortado.' }

Say 'Preparar os ficheiros do instalador...'
if (Test-Path $stage) {
    $expectedStage = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'dist\stage'))
    if ((Resolve-Path -LiteralPath $stage).Path -ne $expectedStage -or
        ((Get-Item -LiteralPath $stage).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        Fail 'Diretorio staging inesperado; limpeza cancelada.'
    }
    Remove-Item -LiteralPath $stage -Force -Recurse
}
New-Item -ItemType Directory -Path $stage -Force | Out-Null
Copy-Item -LiteralPath $exe.FullName -Destination (Join-Path $stage 'LYNX.exe')
foreach ($name in @('LICENSE','THIRD_PARTY.md','PRIVACY.md','CRANKWARE_BRANDING.md')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $stage $name)
}
$versionMatch = Select-String -Path (Join-Path $PSScriptRoot 'CMakeLists.txt') -Pattern 'project\(LYNX VERSION ([0-9.]+)'
if (-not $versionMatch) { Fail 'Versao nao encontrada em CMakeLists.txt' }
$version = $versionMatch.Matches[0].Groups[1].Value
$outfile = Join-Path $dist 'CRANKWARE-ROT-Setup-x64.exe'
$icon = Join-Path $PSScriptRoot 'resources\CRANKWARE.ico'
$script = Join-Path $PSScriptRoot 'resources\installer\CRANKWARE.nsi'
Say 'Compilar instalador NSIS de CRANKWARE...'
& $nsis '-V2' '-INPUTCHARSET' 'UTF8' "-DVERSION=$version" "-DSTAGE=$stage" "-DOUTFILE=$outfile" "-DICON=$icon" $script
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $outfile)) { Fail 'NSIS falhou. Nenhum instalador valido foi gerado.' }
$portable = Join-Path $dist 'CRANKWARE-ROT-Portable-x64.zip'
if (Test-Path $portable) { Remove-Item $portable -Force }
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $portable
$hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $outfile).Hash
Set-Content -LiteralPath (Join-Path $dist 'CRANKWARE-ROT-Setup-x64.sha256.txt') -Value "$hash  CRANKWARE-ROT-Setup-x64.exe" -Encoding ASCII
Say 'INSTALADOR PRONTO:'
Write-Host $outfile -ForegroundColor Cyan
Say 'ZIP PORTATIL PRONTO:'
Write-Host $portable -ForegroundColor Cyan
Write-Host 'Atencao: o instalador e unsigned (nao tem assinatura de codigo). Pode aparecer SmartScreen.' -ForegroundColor Yellow
